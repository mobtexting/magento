<?php

namespace MOBTEXTING\SMS\Observer;

use Magento\Framework\Event\ObserverInterface;
use \Magento\Framework\Event\Observer as Observer;
use \Magento\Framework\View\Element\Context as Context;
use \MOBTEXTING\SMS\Helper\Data as Helper;

/**
 * Customer login observer
 */
class SMSlocal
{
    const REQUEST_URL = 'https://portal.mobtexting.com/api/v2/sms/send/';
    const REQUEST_TIMEOUT = 60;
    const REQUEST_HANDLER = 'curl';
    public $helper;
    public $errors = array();
    public $warnings = array();
    public $lastRequest = array();
    private $username;
    private $hash;
    private $apiKey;
    private $errorReporting = false;

    /**
     * Instantiate the object
     * @param $username
     * @param $hash
     */
    public function __construct(
        $username,
        $hash,
        $apiKey = false,
        $helper
    )
    {
        $this->_helper = $helper;
        $this->username = $username;
        $this->hash = $hash;
        if ($apiKey) {
            $this->apiKey = $apiKey;
        }
    }

    /**
     * Get last request's parameters
     * @return array
     */
    public function getLastRequest()
    {
        return $this->lastRequest;
    }

    /**
     * Send an MMS to a one or more comma separated contacts
     * @param       $numbers
     * @param       $fileSource - either an absolute or relative path, or http url to a file.
     * @param       $message
     * @param null $sched
     * @param false $test
     * @param false $optouts
     * @return array|mixed
     * @throws \Exception
     */
    public function sendMms($numbers, $fileSource, $message, $sched = null, $test = false, $optouts = false)
    {

        if (!is_array($numbers))
            throw new \Exception('Invalid $numbers format. Must be an array');
        if (empty($message))
            throw new \Exception('Empty message');
        if (empty($fileSource))
            throw new \Exception('Empty file source');
        if (!is_null($sched) && !is_numeric($sched))
            throw new \Exception('Invalid date format. Use numeric epoch format');
        $params = array(
            'message' => rawurlencode($message),
            'numbers' => implode(',', $numbers),
            'schedule_time' => $sched,
            'test' => $test,
            'optouts' => $optouts
        );
        /** Local file. POST to service */
        if (is_readable($fileSource))
            $params['file'] = '@' . $fileSource;
        else $params['url'] = $fileSource;
        return $this->_sendRequest('send_mms', $params);
    }

    /**
     * Private function to construct and send the request and handle the response
     * @param       $command
     * @param array $params
     * @return array|mixed
     * @throws \Exception
     * @todo Add additional request handlers - eg fopen, file_get_contacts
     */
    public function _sendRequest($command, $params = array())
    {
        $this->apiKey = 'BHjpSxtFrB4-jy8lstnIU5BL93qfl3oAjX2x7IVbFe';
        if ($this->apiKey && !empty($this->apiKey)) {
            $params['apiKey'] = $this->apiKey;

        } else {
            $params['hash'] = $this->hash;
        }
        // Create request string
        $params['username'] = $this->username;
        $this->lastRequest = $params;

        if (self::REQUEST_HANDLER == 'curl')
            $rawResponse = $this->_sendRequestCurl($command, $params);
        else throw new \Exception('Invalid request handler.');

        $result = json_decode($rawResponse);
        if ($result->status == 'failure') {
            return;
        }
        if ($result->status == 'success') {
        }
        return $result;
    }

    /**
     * Curl request handler
     * @param $command
     * @param $params
     * @return mixed
     * @throws Exception
     */
    private function _sendRequestCurl($command, $params)
    {
        return '{"default_sender_name":"MOBtxt","sender_names":["MOBtxt"],"status":"success"}';
        $url = self::REQUEST_URL . $command . '/';
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $params,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_TIMEOUT => self::REQUEST_TIMEOUT
        ));

        $rawResponse = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($rawResponse === false) {
            throw new \Exception('Failed to connect to the SMS service: ' . $error);
        } elseif ($httpCode != 200) {
            throw new \Exception('Bad response from the SMS service: HTTP code ' . $httpCode);
        }

        return $rawResponse;
    }

    /**
     * Send an MMS to a group - group IDs can be
     * @param       $groupId
     * @param       $fileSource
     * @param       $message
     * @param null $sched
     * @param false $test
     * @param false $optouts
     * @return array|mixed
     * @throws \Exception
     */
    public function sendMmsGroup($groupId, $fileSource, $message, $sched = null, $test = false, $optouts = false)
    {

        if (!is_numeric($groupId))
            throw new \Exception('Invalid $groupId format. Must be a numeric group ID');
        if (empty($message))
            throw new \Exception('Empty message');
        if (empty($fileSource))
            throw new \Exception('Empty file source');
        if (!is_null($sched) && !is_numeric($sched))
            throw new \Exception('Invalid date format. Use numeric epoch format');

        $params = array(
            'message' => rawurlencode($message),
            'group_id' => $groupId,
            'schedule_time' => $sched,
            'test' => $test,
            'optouts' => $optouts
        );

        /** Local file. POST to service */
        if (is_readable($fileSource))
            $params['file'] = '@' . $fileSource;
        else $params['url'] = $fileSource;

        return $this->_sendRequest('send_mms', $params);
    }

    /**
     *Returns reseller customer's ID's
     * @return array
     **/
    public function getUsers()
    {
        return $this->_sendRequest('get_users');
    }

    /**
     * Transfer credits to a reseller's customer
     * @param $user - can be ID or Email
     * @param $credits
     * @return array|mixed
     * @throws \Exception
     **/

    public function transferCredits($user, $credits)
    {

        if (!is_numeric($credits))
            throw new \Exception('Invalid credits format');
        if (!is_numeric($user))
            throw new \Exception('Invalid user');
        if (empty($user))
            throw new \Exception('No user specified');
        if (empty($credits))
            throw new \Exception('No credits specified');
        if (is_int($user)) {
            $params = array(
                'user_id' => $user,
                'credits' => $credits
            );
        } else {
            $params = array(
                'user_email' => rawurlencode($user),
                'credits' => $credits
            );
        }

        return $this->_sendRequest('transfer_credits', $params);
    }

    /**Get templates from an account **/
    public function getTemplates()
    {
        return $this->_sendRequest('get_templates');
    }

    /** Check the availability of a keyword
     * @param $keyword
     * return array|mixed
     */
    public function checkKeyword($keyword)
    {
        $params = array('keyword' => $keyword);
        return $this->_sendRequest('check_keyword', $params);
    }

    /**
     * Create a new contact group
     * @param $name
     * @return array|mixed
     */
    public function createGroup($name)
    {
        $params = array('name' => $name);
        return $this->_sendRequest('create_group', $params);
    }

    /**
     * Get contacts from a group - Group IDs can be retrieved with the getGroups() function
     * @param     $groupId
     * @param     $limit
     * @param int $startPos
     * @return array|mixed
     * @throws \Exception
     */
    public function getContacts($groupId, $limit, $startPos = 0)
    {
        if (!is_numeric($groupId))
            throw new \Exception('Invalid $groupId format. Must be a numeric group ID');
        if (!is_numeric($startPos) || $startPos < 0)
            throw new \Exception('Invalid $startPos format. Must be a numeric start position, 0 or above');
        if (!is_numeric($limit) || $limit < 1)
            throw new \Exception('Invalid $limit format. Must be a numeric limit value, 1 or above');

        $params = array(
            'group_id' => $groupId,
            'start' => $startPos,
            'limit' => $limit
        );
        return $this->_sendRequest('get_contacts', $params);
    }

    /**
     * Create one or more number-only contacts in a specific group, defaults to 'My Contacts'
     * @param        $numbers
     * @param string $groupid
     * @return array|mixed
     */
    public function createContacts($numbers, $groupid = '5')
    {
        $params = array("group_id" => $groupid);

        if (is_array($numbers)) {
            $params['numbers'] = implode(',', $numbers);
        } else {
            $params['numbers'] = $numbers;
        }

        return $this->_sendRequest('create_contacts', $params);
    }

    /**
     * Create bulk contacts - with name and custom information from an array of:
     * [first_name] [last_name] [number] [custom1] [custom2] [custom3]
     *
     * @param array $contacts
     * @param string $groupid
     * @return array|mixed
     */
    function createContactsBulk($contacts, $groupid = '5')
    {
        $contacts = rawurlencode(json_encode($contacts));
        $params = array
        ("group_id" => $groupid, "contacts" => $contacts);
        return $this->_sendRequest('create_contacts_bulk', $params);
    }

    /**
     * Get a list of groups and group IDs
     * @return array|mixed
     */
    public function getGroups()
    {
        return $this->_sendRequest('get_groups');
    }

    /**
     * Get the status of a message based on the Message ID - this can be taken from sendSMS or from a history report
     * @param $messageid
     * @return array|mixed
     */
    public function getMessageStatus($messageid)
    {
        $params = array("message_id" => $messageid);
        return $this->_sendRequest('status_message', $params);
    }

    /**
     * Get the status of a message based on the Batch ID - this can be taken from sendSMS or from a history report
     * @param $batchid
     * @return array|mixed
     */
    public function getBatchStatus($batchid)
    {
        $params = array("batch_id" => $batchid);
        return $this->_sendRequest('status_batch', $params);
    }

    /**
     * Get sender names
     * @return array|mixed
     */
    public function getSenderNames()
    {
        return $this->_sendRequest('get_sender_names');
    }

    /**
     * Get inboxes available on the account
     * @return array|mixed
     */
    public function getInboxes()
    {
        return $this->_sendRequest('get_inboxes');
    }

    /**
     * Get Credit Balances
     * @return array
     */
    public function getBalance()
    {
        $result = $this->_sendRequest('balance');
        return array('sms' => $result->balance->sms, 'mms' => $result->balance->mms);
    }

    /**
     * Get messages from an inbox - The ID can ge retrieved from getInboxes()
     * @param $inbox
     * @return array|bool|mixed
     */
    public function getMessages($inbox)
    {
        if (!isset($inbox)) return false;
        $options = array('inbox_id' => $inbox);
        return $this->_sendRequest('get_messages', $options);
    }

    /**
     * Cancel a scheduled message based on a message ID from getScheduledMessages()
     * @param $id
     * @return array|bool|mixed
     */
    public function cancelScheduledMessage($id)
    {
        if (!isset($id)) return false;
        $options = array('sent_id' => $id);
        return $this->_sendRequest('cancel_scheduled', $options);
    }

    /**
     * Get Scheduled Message information
     * @return array|mixed
     */
    public function getScheduledMessages()
    {
        return $this->_sendRequest('get_scheduled');
    }

    /**
     * Delete a contact based on telephone number from a group
     * @param     $number
     * @param int $groupid
     * @return array|bool|mixed
     */
    public function deleteContact($number, $groupid = 5)
    {
        if (!isset($number)) return false;
        $options = array('number' => $number, 'group_id' => $groupid);
        return $this->_sendRequest('delete_contact', $options);
    }

    /**
     * Delete a group - Be careful, we can not recover any data deleted by mistake
     * @param $groupid
     * @return array|mixed
     */
    public function deleteGroup($groupid)
    {
        $options = array('group_id' => $groupid);
        return $this->_sendRequest('delete_group', $options);
    }

    /**
     * Get single SMS history (single numbers, comma seperated numbers when sending)
     * @param $start
     * @param $limit
     * @param $min_time             Unix timestamp
     * @param $max_time             Unix timestamp
     * @return array|bool|mixed
     */
    public function getSingleMessageHistory($start, $limit, $min_time, $max_time)
    {
        return $this->getHistory('get_history_single', $start, $limit, $min_time, $max_time);
    }

    /**
     * Generic function to provide validation and the request method for getting all types of history
     * @param $type
     * @param $start
     * @param $limit
     * @param $min_time
     * @param $max_time
     * @return array|bool|mixed
     */
    private function getHistory($type, $start, $limit, $min_time, $max_time)
    {

        if (!isset($start) || !isset($limit) || !isset($min_time) || !isset($max_time)) return false;
        $options = array('start' => $start, 'limit' => $limit, 'min_time' => $min_time, 'max_time' => $max_time);
        return $this->_sendRequest($type, $options);
    }

    /**
     * Get API SMS Message history
     * @param $start
     * @param $limit
     * @param $min_time             Unix timestamp
     * @param $max_time             Unix timestamp
     * @return array|bool|mixed
     */
    public function getAPIMessageHistory($start, $limit, $min_time, $max_time)
    {
        return $this->getHistory('get_history_api', $start, $limit, $min_time, $max_time);
    }

    /**
     * Get Email to SMS History
     * @param $start
     * @param $limit
     * @param $min_time             Unix timestamp
     * @param $max_time             Unix timestamp
     * @return array|bool|mixed
     */
    public function getEmailToSMSHistory($start, $limit, $min_time, $max_time)
    {
        return $this->getHistory('get_history_email', $start, $limit, $min_time, $max_time);
    }

    /**
     * Get group SMS history
     * @param $start
     * @param $limit
     * @param $min_time             Unix timestamp
     * @param $max_time             Unix timestamp
     * @return array|bool|mixed
     */
    public function getGroupMessageHistory($start, $limit, $min_time, $max_time)
    {
        return $this->getHistory('get_history_group', $start, $limit, $min_time, $max_time);
    }

    /**
     * fopen() request handler
     * @param $command
     * @param $params
     * @throws \Exception
     */
    private function _sendRequestFopen()
    {
        throw new \Exception('Unsupported transfer method');
    }
}
